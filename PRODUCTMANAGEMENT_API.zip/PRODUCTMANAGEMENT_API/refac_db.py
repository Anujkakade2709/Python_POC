from ProductModel import *
from UserModel import *
from SellerModel import *
from CartModel import *
from OrderModel import *
from ReqParser import *
from db_sql import *
from config import *
from flask import Flask,jsonify,request
from flask_restful import Api
from flask_mysqldb import MySQL

app = Flask(__name__)
api = Api(app)

app.config['MYSQL_HOST'] = db_host
app.config['MYSQL_USER'] = db_user
app.config['MYSQL_PASSWORD'] = db_password
app.config['MYSQL_DB'] = db_name

mysql = MySQL(app)

Product_put_args = parseProductInfo()




#Product API Endpoints
@app.route('/Products')
def getAllProducts():
    try:
        query = 'SELECT * FROM products'
        records = getTable(mysql,query,())
        return jsonify(parseProductTable(records))
    except:
        return jsonify("error")

@app.route('/Product/<string:id>',methods=['PUT','GET'])
def getProduct(id):
    if (request.method == 'PUT'):
        args = Product_put_args.parse_args()
        try:
            insertProductValue(mysql,args)
            return jsonify("Success")
        except:
            return jsonify("Failure,Maybe Product Id is alredy present in the database")
        
    if (request.method == 'GET'):
        try:
            query = 'SELECT * FROM products WHERE P_id = %s'
            records = getTable(mysql,query,(id))
            row = records[0]
            obj = getProductJson(row)
            return jsonify(obj)
        except:
            return jsonify("Incorrect Product ID")

            


#User API Endpoints
@app.route('/Users')
def getAllUsers():
    try:
        query = 'SELECT * FROM users'
        records = getTable(mysql,query,())
        return jsonify(parseUserTable(records))
    except:
        return jsonify("error")

@app.route('/User/<string:id>',methods=['PUT','GET'])
def getUser(id):
    if (request.method == 'PUT'):
        args = User_put_args.parse_args()
        try:
            insertUserValue(mysql,args)
            return jsonify("Success")
        except:
            return jsonify("Failure,Maybe user Id is alredy present in the database")
        
    if (request.method == 'GET'):
        try:
            query = 'SELECT * FROM users WHERE U_id = %s'
            records = getTable(mysql,query,(id))
            row = records[0]
            obj = getUserJson(row)
            return jsonify(obj)
        except:
            return jsonify("Incorrect User ID")

@app.route('/User/<string:id>',methods=['DELETE'])
def deleteUser(id):
    try:
            query = 'DELETE * FROM users WHERE U_id = %s'
            records = getTable(mysql,query,(id))
            row = records[0]
            obj = getUserJson(row)
            return jsonify(obj)
        except:
            return jsonify("Incorrect User ID")




#Seller API Endpoints
@app.route('/Sellers')
def getAllUsers():
    try:
        query = 'SELECT * FROM sellers'
        records = getTable(mysql,query,())
        return jsonify(parseSellerTable(records))
    except:
        return jsonify("error")

@app.route('/Seller/<string:id>',methods=['PUT','GET'])
def getSeller(id):
    if (request.method == 'PUT'):
        args = Seller_put_args.parse_args()
        try:
            insertSellerValue(mysql,args)
            return jsonify("Success")
        except:
            return jsonify("Failure,Maybe seller Id is alredy present in the database")
        
    if (request.method == 'GET'):
        try:
            query = 'SELECT * FROM sellers WHERE Seller_id = %s'
            records = getTable(mysql,query,(id))
            row = records[0]
            obj = getSellerJson(row)
            return jsonify(obj)
        except:
            return jsonify("Incorrect Seller ID")










#Order API Endpoints
@app.route('/Orders')
def getAllUsers():
    try:
        query = 'SELECT * FROM orders'
        records = getTable(mysql,query,())
        return jsonify(parseOrderTable(records))
    except:
        return jsonify("error")

@app.route('/Order/<string:id>',methods=['PUT','GET'])
def getOrder(id):
    if (request.method == 'PUT'):
        args = Order_put_args.parse_args()
        try:
            insertOrderValue(mysql,args)
            return jsonify("Success")
        except:
            return jsonify("Failure,Maybe order Id is alredy present in the database")
        
    if (request.method == 'GET'):
        try:
            query = 'SELECT * FROM orders WHERE O_id = %s'
            records = getTable(mysql,query,(id))
            row = records[0]
            obj = getOrderJson(row)
            return jsonify(obj)
        except:
            return jsonify("Incorrect Order ID")










#Cart API Endpoints
@app.route('/Cart')
def getAllUsers():
    try:
        query = 'SELECT * FROM cart'
        records = getTable(mysql,query,())
        return jsonify(parseCartTable(records))
    except:
        return jsonify("error")

@app.route('/Cart/<string:id>',methods=['PUT','GET'])
def getUser(id):
    if (request.method == 'PUT'):
        args = Cart_put_args.parse_args()
        try:
            insertCartValue(mysql,args)
            return jsonify("Success")
        except:
            return jsonify("Failure,Maybe cart Id is alredy present in the database")
        
    if (request.method == 'GET'):
        try:
            query = 'SELECT * FROM cart WHERE C_id = %s'
            records = getTable(mysql,query,(id))
            row = records[0]
            obj = getCartJson(row)
            return jsonify(obj)
        except:
            return jsonify("Incorrect Cart ID")






if __name__ == "__main__":
	app.run(debug=True)