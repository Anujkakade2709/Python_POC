def getProductJson(row):
    obj = {}
    obj["P_id"]=row[0]
    obj["Name"]=row[1]
    obj["Descr"]=row[2]
    obj["Type"]=row[3]
    obj["Seller_id"]=row[4]
    return obj

def parseProductTable(records):
    response = {}
    for row in records:
        obj = getProductJson(row)
        response[row[0]] = obj
    return response

def insertProductValue(mysql,args):
    cur = mysql.connection.cursor()
    cur.execute('INSERT INTO products VALUES(%s,%s,%s,%s,%s)',(args["P_id"],args["Name"],args["Descr"],str(args["Type"]),args["Seller_id"]))
    mysql.connection.commit()
    cur.close()