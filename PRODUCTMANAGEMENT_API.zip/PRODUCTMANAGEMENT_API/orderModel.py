def getOrderJson(row):
    obj = {}
    obj["O_id"]=row[0]
    obj["U_id"]=row[1]
    obj["C_id"]=row[2]
    obj["Quantity"]=row[3]
    obj["date"]=row[4]
    return obj

def parseOrderTable(records):
    response = {}
    for row in records:
        obj = getOrderJson(row)
        response[row[0]] = obj
    return response

def insertOrderValue(mysql,args):
    cur = mysql.connection.cursor()
    cur.execute('INSERT INTO order VALUES(%s,%s,%s,%s,%s)',(args["O_id"],args["U_id"],args["C_id"],str(args["Quantity"]),args["date"]))
    mysql.connection.commit()
    cur.close()


    '''
    def parseOrderInfo():
    Product_put_args = reqparse.RequestParser()
    Product_put_args.add_argument("U_id", type=str, help="Name  is required", required=True)
    Product_put_args.add_argument("C_id", type=str, help="Descr is required", required=True)
    Product_put_args.add_argument("O_id", type=str, help="s_id is required", required=True)
    Product_put_args.add_argument("Quantity", type=str, help="type is required", required=True)
    Product_put_args.add_argument("date", type=str, help="required", required=True)
    return Order_put_args

    '''