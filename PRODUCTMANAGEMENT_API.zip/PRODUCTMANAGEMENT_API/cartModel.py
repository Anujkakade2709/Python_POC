
def getCartJson(row):
    obj = {}
    obj["U_id"]=row[0]
    obj["C_id"]=row[1]
    obj["Quantity"]=row[2]
    return obj

def parseCartTable(records):
    response = {}
    for row in records:
        obj = getCartJson(row)
        response[row[0]] = obj
    return response

def insertCartValue(mysql,args):
    cur = mysql.connection.cursor()
    cur.execute('INSERT INTO cart VALUES(%s,%s,%s,%s,%s)',(args["U_id"],args["C_id"],str(args["Quantity"])))
    mysql.connection.commit()
    cur.close()


'''

def parseCartInfo():
    Cart_put_args = reqparse.RequestParser()
    Cart_put_args.add_argument("U_id", type=str, help="Name  is required", required=True)
    Cart_put_args.add_argument("C_id", type=str, help="s_id is required", required=True)
    Cart_put_args.add_argument("Quantity", type=str, help="type is required", required=True)
    return Cart_put_args
'''