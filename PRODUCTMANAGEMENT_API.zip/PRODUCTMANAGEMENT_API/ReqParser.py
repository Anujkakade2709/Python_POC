from flask_restful import reqparse



def parseProductInfo():
    Product_put_args = reqparse.RequestParser()
    Product_put_args.add_argument("Name", type=str, help="Name  is required", required=True)
    Product_put_args.add_argument("Descr", type=str, help="Descr is required", required=True)
    Product_put_args.add_argument("S_id", type=str, help="s_id is required", required=True)
    Product_put_args.add_argument("Type", type=str, help="type is required", required=True)
    Product_put_args.add_argument("Seller_id", type=str, help="required", required=True)
    return Product_put_args



def parseUserInfo():
    User_put_args = reqparse.RequestParser()
    User_put_args.add_argument("Name", type=str, help="Name  is required", required=True)
    User_put_args.add_argument("Descr", type=str, help="Descr is required", required=True)
    User_put_args.add_argument("U_id", type=str, help="user_id is required", required=True)
    User_put_args.add_argument("Phone", type=str, help="phone is required", required=True)
    User_put_args.add_argument("Address", type=str, help="required", required=True)
    return User_put_args



def parseSellerInfo():
    Seller_put_args = reqparse.RequestParser()
    Seller_put_args.add_argument("Name", type=str, help="Name  is required", required=True)
    Seller_put_args.add_argument("Descr", type=str, help="Descr is required", required=True)
    Seller_put_args.add_argument("Seller_id", type=str, help="seller_id is required", required=True)
    Seller_put_args.add_argument("Phone", type=str, help="phone is required", required=True)
    Seller_put_args.add_argument("Address", type=str, help="required", required=True)
    return Seller_put_args



def parseCartInfo():
    Cart_put_args = reqparse.RequestParser()
    Cart_put_args.add_argument("U_id", type=str, help="Name  is required", required=True)
    Cart_put_args.add_argument("C_id", type=str, help="s_id is required", required=True)
    Cart_put_args.add_argument("Quantity", type=str, help="type is required", required=True)
    return Cart_put_args




def parseOrderInfo():
    Product_put_args = reqparse.RequestParser()
    Product_put_args.add_argument("U_id", type=str, help="Name  is required", required=True)
    Product_put_args.add_argument("C_id", type=str, help="Descr is required", required=True)
    Product_put_args.add_argument("O_id", type=str, help="s_id is required", required=True)
    Product_put_args.add_argument("Quantity", type=str, help="type is required", required=True)
    Product_put_args.add_argument("date", type=str, help="required", required=True)
    return Order_put_args





