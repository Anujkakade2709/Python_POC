def getUserJson(row):
    obj = {}
    obj["U_id"]=row[0]
    obj["Name"]=row[1]
    obj["Descr"]=row[2]
    obj["Phone"]=row[3]
    obj["Address"]=row[4]
    return obj

def parseUserTable(records):
    response = {}
    for row in records:
        obj = getUserJson(row)
        response[row[0]] = obj
    return response

def insertUserValue(mysql,args):
    cur = mysql.connection.cursor()
    cur.execute('INSERT INTO users VALUES(%s,%s,%s,%s,%s)',(args["U_id"],args["Name"],args["Descr"],str(args["Phone"]),args["Address"]))
    mysql.connection.commit()
    cur.close()